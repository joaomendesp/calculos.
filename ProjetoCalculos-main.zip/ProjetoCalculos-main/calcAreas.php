<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./calcAreas.css">

    <title>Calculadora de Áreas</title>
</head>
<body>
        <div class="container">
            <h1 class="titulo1">Calculadora de Áreas</h1>
                <a href="areaCirculo.php"><button class="botao">Círculo</button></a><br><br>
                <a href="areaTriangulo.php"><button class="botao">Triânulo</button></a><br><br>
                <a href="areaRetangulo.php"><button class="botao">Retângulo</button></a><br><br>
                <a href="index.php"><button class="botao">Voltar</button></a><br><br>
        </div>
    
</body>
</html>